import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// PUT /api/movimientos/:id - Editar movimiento
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const movimientoId = parseInt(id)
    const body = await request.json()
    const { tipo, concepto, categoria, importe, fecha, cuenta, notas } = body

    if (!tipo || !['ingreso', 'gasto'].includes(tipo)) {
      return NextResponse.json({ error: 'Tipo inválido' }, { status: 400 })
    }
    if (!concepto || concepto.trim().length === 0) {
      return NextResponse.json({ error: 'El concepto es obligatorio' }, { status: 400 })
    }
    if (!importe || importe <= 0) {
      return NextResponse.json({ error: 'El importe debe ser mayor que 0' }, { status: 400 })
    }
    if (!fecha) {
      return NextResponse.json({ error: 'La fecha es obligatoria' }, { status: 400 })
    }

    const anterior = await db.movimiento.findUnique({ where: { id: movimientoId } })
    if (!anterior) {
      return NextResponse.json({ error: 'Movimiento no encontrado' }, { status: 404 })
    }

    // Revertir saldo de la cuenta anterior
    const cuentaAnt = await db.cuenta.findFirst({ where: { nombre: anterior.cuenta } })
    if (cuentaAnt) {
      const rev = anterior.tipo === 'ingreso' ? cuentaAnt.saldo - anterior.importe : cuentaAnt.saldo + anterior.importe
      await db.cuenta.update({ where: { id: cuentaAnt.id }, data: { saldo: Math.round(rev * 100) / 100 } })
    }

    const movimiento = await db.movimiento.update({
      where: { id: movimientoId },
      data: {
        tipo, concepto: concepto.trim(), categoria: categoria.trim(),
        importe: parseFloat(importe), fecha: new Date(fecha),
        cuenta: cuenta.trim(), notas: notas?.trim() || null,
      },
    })

    // Aplicar nuevo saldo
    const nuevaCuenta = await db.cuenta.findFirst({ where: { nombre: cuenta.trim() } })
    if (nuevaCuenta) {
      const nuevoSaldo = tipo === 'ingreso' ? nuevaCuenta.saldo + parseFloat(importe) : nuevaCuenta.saldo - parseFloat(importe)
      await db.cuenta.update({ where: { id: nuevaCuenta.id }, data: { saldo: Math.round(nuevoSaldo * 100) / 100 } })
    }

    return NextResponse.json(movimiento)
  } catch (error) {
    console.error('Error al editar movimiento:', error)
    return NextResponse.json({ error: 'Error al editar movimiento' }, { status: 500 })
  }
}

// DELETE /api/movimientos/:id - Eliminar movimiento
export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const movimientoId = parseInt(id)

    const movimiento = await db.movimiento.findUnique({ where: { id: movimientoId } })
    if (!movimiento) {
      return NextResponse.json({ error: 'Movimiento no encontrado' }, { status: 404 })
    }

    // Revertir saldo
    const cuenta = await db.cuenta.findFirst({ where: { nombre: movimiento.cuenta } })
    if (cuenta) {
      const nuevoSaldo = movimiento.tipo === 'ingreso' ? cuenta.saldo - movimiento.importe : cuenta.saldo + movimiento.importe
      await db.cuenta.update({ where: { id: cuenta.id }, data: { saldo: Math.round(nuevoSaldo * 100) / 100 } })
    }

    await db.movimiento.delete({ where: { id: movimientoId } })
    return NextResponse.json({ mensaje: 'Movimiento eliminado correctamente' })
  } catch (error) {
    console.error('Error al eliminar movimiento:', error)
    return NextResponse.json({ error: 'Error al eliminar movimiento' }, { status: 500 })
  }
}
