import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// GET /api/movimientos - Listar movimientos con filtros opcionales
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const tipo = searchParams.get('tipo')
    const categoria = searchParams.get('categoria')
    const cuenta = searchParams.get('cuenta')
    const desde = searchParams.get('desde')
    const hasta = searchParams.get('hasta')
    const buscar = searchParams.get('buscar')
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '50')

    const where: Record<string, unknown> = {}

    if (tipo) where.tipo = tipo
    if (categoria) where.categoria = categoria
    if (cuenta) where.cuenta = cuenta
    if (buscar) {
      where.OR = [
        { concepto: { contains: buscar } },
        { categoria: { contains: buscar } },
        { cuenta: { contains: buscar } },
        { notas: { contains: buscar } },
      ]
    }
    if (desde || hasta) {
      where.fecha = {}
      if (desde) where.fecha.gte = new Date(desde)
      if (hasta) where.fecha.lte = new Date(hasta)
    }

    const total = await db.movimiento.count({ where })
    const movimientos = await db.movimiento.findMany({
      where,
      orderBy: { fecha: 'desc' },
      skip: (page - 1) * limit,
      take: limit,
    })

    return NextResponse.json({ movimientos, total, page, limit })
  } catch (error) {
    console.error('Error al listar movimientos:', error)
    return NextResponse.json(
      { error: 'Error al listar movimientos' },
      { status: 500 }
    )
  }
}

// POST /api/movimientos - Crear movimiento
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { tipo, concepto, categoria, importe, fecha, cuenta, notas } = body

    // Validaciones
    if (!tipo || !['ingreso', 'gasto'].includes(tipo)) {
      return NextResponse.json(
        { error: 'Tipo inválido. Debe ser "ingreso" o "gasto"' },
        { status: 400 }
      )
    }
    if (!concepto || concepto.trim().length === 0) {
      return NextResponse.json(
        { error: 'El concepto es obligatorio' },
        { status: 400 }
      )
    }
    if (!categoria || categoria.trim().length === 0) {
      return NextResponse.json(
        { error: 'La categoría es obligatoria' },
        { status: 400 }
      )
    }
    if (!importe || importe <= 0) {
      return NextResponse.json(
        { error: 'El importe debe ser mayor que 0' },
        { status: 400 }
      )
    }
    if (!fecha) {
      return NextResponse.json(
        { error: 'La fecha es obligatoria' },
        { status: 400 }
      )
    }
    if (!cuenta || cuenta.trim().length === 0) {
      return NextResponse.json(
        { error: 'La cuenta es obligatoria' },
        { status: 400 }
      )
    }

    // Crear movimiento
    const movimiento = await db.movimiento.create({
      data: {
        tipo,
        concepto: concepto.trim(),
        categoria: categoria.trim(),
        importe: parseFloat(importe),
        fecha: new Date(fecha),
        cuenta: cuenta.trim(),
        notas: notas?.trim() || null,
      },
    })

    // Actualizar saldo de la cuenta
    const cuentaDb = await db.cuenta.findFirst({
      where: { nombre: cuenta.trim() },
    })
    if (cuentaDb) {
      const nuevoSaldo =
        tipo === 'ingreso'
          ? cuentaDb.saldo + parseFloat(importe)
          : cuentaDb.saldo - parseFloat(importe)
      await db.cuenta.update({
        where: { id: cuentaDb.id },
        data: { saldo: Math.round(nuevoSaldo * 100) / 100 },
      })
    }

    return NextResponse.json(movimiento, { status: 201 })
  } catch (error) {
    console.error('Error al crear movimiento:', error)
    return NextResponse.json(
      { error: 'Error al crear movimiento' },
      { status: 500 }
    )
  }
}
