import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

// GET /api/dashboard - Estadísticas generales del dashboard
export async function GET() {
  try {
    const now = new Date()
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1)
    const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59)

    // Todos los movimientos
    const todosMovimientos = await db.movimiento.findMany()

    // Movimientos del mes actual
    const movimientosMes = await db.movimiento.findMany({
      where: {
        fecha: { gte: startOfMonth, lte: endOfMonth },
      },
    })

    // Totales globales
    const totalIngresos = todosMovimientos
      .filter((m) => m.tipo === 'ingreso')
      .reduce((sum, m) => sum + m.importe, 0)

    const totalGastos = todosMovimientos
      .filter((m) => m.tipo === 'gasto')
      .reduce((sum, m) => sum + m.importe, 0)

    // Totales del mes
    const ingresosMes = movimientosMes
      .filter((m) => m.tipo === 'ingreso')
      .reduce((sum, m) => sum + m.importe, 0)

    const gastosMes = movimientosMes
      .filter((m) => m.tipo === 'gasto')
      .reduce((sum, m) => sum + m.importe, 0)

    // Saldo por cuentas
    const cuentas = await db.cuenta.findMany()

    // Últimos 10 movimientos
    const ultimosMovimientos = await db.movimiento.findMany({
      orderBy: { fecha: 'desc' },
      take: 10,
    })

    // Gastos por categoría (mes actual)
    const gastosPorCategoria: Record<string, number> = {}
    movimientosMes
      .filter((m) => m.tipo === 'gasto')
      .forEach((m) => {
        gastosPorCategoria[m.categoria] =
          (gastosPorCategoria[m.categoria] || 0) + m.importe
      })

    // Ingresos por mes (últimos 6 meses)
    const ingresosPorMes: Record<string, number> = {}
    const gastosPorMes: Record<string, number> = {}
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1)
      const monthEnd = new Date(d.getFullYear(), d.getMonth() + 1, 0, 23, 59, 59)
      const monthKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
      const monthLabel = d.toLocaleDateString('es-ES', {
        month: 'short',
        year: '2-digit',
      })

      const monthMovs = await db.movimiento.findMany({
        where: { fecha: { gte: d, lte: monthEnd } },
      })

      const key = `${monthLabel} ${d.getFullYear()}`
      ingresosPorMes[key] = monthMovs
        .filter((m) => m.tipo === 'ingreso')
        .reduce((s, m) => s + m.importe, 0)
      gastosPorMes[key] = monthMovs
        .filter((m) => m.tipo === 'gasto')
        .reduce((s, m) => s + m.importe, 0)
    }

    // Evolución del saldo (últimos 12 meses)
    const evolucionSaldo: Record<string, number> = {}
    let saldoAcumulado = 0
    for (let i = 11; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1)
      const monthEnd = new Date(d.getFullYear(), d.getMonth() + 1, 0, 23, 59, 59)
      const monthLabel = d.toLocaleDateString('es-ES', {
        month: 'short',
      })

      const monthMovs = await db.movimiento.findMany({
        where: { fecha: { gte: d, lte: monthEnd } },
      })

      monthMovs.forEach((m) => {
        saldoAcumulado += m.tipo === 'ingreso' ? m.importe : -m.importe
      })
      evolucionSaldo[monthLabel] = Math.round(saldoAcumulado * 100) / 100
    }

    return NextResponse.json({
      saldoTotal: totalIngresos - totalGastos,
      totalIngresos,
      totalGastos,
      balanceMensual: ingresosMes - gastosMes,
      ingresosMes,
      gastosMes,
      cuentas,
      ultimosMovimientos,
      gastosPorCategoria,
      ingresosPorMes,
      gastosPorMes,
      evolucionSaldo,
    })
  } catch (error) {
    console.error('Error en dashboard:', error)
    return NextResponse.json(
      { error: 'Error al cargar el dashboard' },
      { status: 500 }
    )
  }
}
