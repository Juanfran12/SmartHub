import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// PUT /api/cuentas/:id - Actualizar saldo de cuenta
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const cuentaId = parseInt(id)
    const body = await request.json()
    const { nombre, saldo } = body

    const cuenta = await db.cuenta.findUnique({ where: { id: cuentaId } })
    if (!cuenta) {
      return NextResponse.json({ error: 'Cuenta no encontrada' }, { status: 404 })
    }

    const updated = await db.cuenta.update({
      where: { id: cuentaId },
      data: {
        nombre: nombre?.trim() || cuenta.nombre,
        saldo: saldo !== undefined ? parseFloat(saldo) : cuenta.saldo,
      },
    })
    return NextResponse.json(updated)
  } catch (error) {
    console.error('Error al actualizar cuenta:', error)
    return NextResponse.json({ error: 'Error al actualizar cuenta' }, { status: 500 })
  }
}

// DELETE /api/cuentas/:id
export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const cuentaId = parseInt(id)

    const cuenta = await db.cuenta.findUnique({ where: { id: cuentaId } })
    if (!cuenta) {
      return NextResponse.json({ error: 'Cuenta no encontrada' }, { status: 404 })
    }

    await db.cuenta.delete({ where: { id: cuentaId } })
    return NextResponse.json({ mensaje: 'Cuenta eliminada correctamente' })
  } catch (error) {
    console.error('Error al eliminar cuenta:', error)
    return NextResponse.json({ error: 'Error al eliminar cuenta' }, { status: 500 })
  }
}
