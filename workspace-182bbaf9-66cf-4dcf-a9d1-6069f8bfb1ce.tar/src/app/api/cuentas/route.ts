import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// GET /api/cuentas - Listar cuentas
export async function GET() {
  try {
    const cuentas = await db.cuenta.findMany({ orderBy: { nombre: 'asc' } })
    return NextResponse.json(cuentas)
  } catch (error) {
    console.error('Error al listar cuentas:', error)
    return NextResponse.json({ error: 'Error al listar cuentas' }, { status: 500 })
  }
}

// POST /api/cuentas - Crear cuenta
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { nombre, saldo } = body

    if (!nombre || nombre.trim().length === 0) {
      return NextResponse.json({ error: 'El nombre es obligatorio' }, { status: 400 })
    }

    const existente = await db.cuenta.findFirst({ where: { nombre: nombre.trim() } })
    if (existente) {
      return NextResponse.json({ error: 'Esta cuenta ya existe' }, { status: 409 })
    }

    const cuenta = await db.cuenta.create({
      data: { nombre: nombre.trim(), saldo: parseFloat(saldo) || 0 },
    })
    return NextResponse.json(cuenta, { status: 201 })
  } catch (error) {
    console.error('Error al crear cuenta:', error)
    return NextResponse.json({ error: 'Error al crear cuenta' }, { status: 500 })
  }
}
