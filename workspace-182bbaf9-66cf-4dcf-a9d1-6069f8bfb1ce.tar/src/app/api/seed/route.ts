import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

// GET /api/seed - Inicializar datos por defecto
export async function GET() {
  try {
    // Crear categorías por defecto si no existen
    const categoriasDefault = [
      'Trabajo', 'Casa', 'Comida', 'Gasolina', 'Ocio',
      'Compras', 'Trading', 'Inversiones', 'Otros',
      'Salud', 'Educación', 'Transporte', 'Suscripciones',
    ]

    for (const nombre of categoriasDefault) {
      await db.categoria.upsert({
        where: { nombre },
        update: {},
        create: { nombre },
      })
    }

    // Crear cuentas por defecto si no existen
    const cuentasDefault = [
      { nombre: 'Banco', saldo: 0 },
      { nombre: 'Efectivo', saldo: 0 },
      { nombre: 'PayPal', saldo: 0 },
      { nombre: 'Revolut', saldo: 0 },
    ]

    for (const c of cuentasDefault) {
      await db.cuenta.upsert({
        where: { nombre: c.nombre },
        update: {},
        create: c,
      })
    }

    return NextResponse.json({ mensaje: 'Datos iniciales cargados correctamente' })
  } catch (error) {
    console.error('Error al inicializar datos:', error)
    return NextResponse.json({ error: 'Error al inicializar datos' }, { status: 500 })
  }
}
