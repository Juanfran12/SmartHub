import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// GET /api/categorias - Listar categorías
export async function GET() {
  try {
    const categorias = await db.categoria.findMany({
      orderBy: { nombre: 'asc' },
    })
    return NextResponse.json(categorias)
  } catch (error) {
    console.error('Error al listar categorías:', error)
    return NextResponse.json({ error: 'Error al listar categorías' }, { status: 500 })
  }
}

// POST /api/categorias - Crear categoría
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { nombre } = body

    if (!nombre || nombre.trim().length === 0) {
      return NextResponse.json({ error: 'El nombre es obligatorio' }, { status: 400 })
    }

    const existente = await db.categoria.findFirst({ where: { nombre: nombre.trim() } })
    if (existente) {
      return NextResponse.json({ error: 'Esta categoría ya existe' }, { status: 409 })
    }

    const categoria = await db.categoria.create({
      data: { nombre: nombre.trim() },
    })
    return NextResponse.json(categoria, { status: 201 })
  } catch (error) {
    console.error('Error al crear categoría:', error)
    return NextResponse.json({ error: 'Error al crear categoría' }, { status: 500 })
  }
}
