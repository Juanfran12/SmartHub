import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

// GET /api/backup - Copia de seguridad completa en JSON
export async function GET() {
  try {
    const [movimientos, categorias, cuentas] = await Promise.all([
      db.movimiento.findMany({ orderBy: { fecha: 'desc' } }),
      db.categoria.findMany({ orderBy: { nombre: 'asc' } }),
      db.cuenta.findMany({ orderBy: { nombre: 'asc' } }),
    ])

    const backup = {
      version: '1.0',
      fecha: new Date().toISOString(),
      datos: { movimientos, categorias, cuentas },
    }

    return new NextResponse(JSON.stringify(backup, null, 2), {
      headers: {
        'Content-Type': 'application/json',
        'Content-Disposition': `attachment; filename="smarthub_backup_${new Date().toISOString().split('T')[0]}.json"`,
      },
    })
  } catch (error) {
    console.error('Error al crear backup:', error)
    return NextResponse.json({ error: 'Error al crear backup' }, { status: 500 })
  }
}
