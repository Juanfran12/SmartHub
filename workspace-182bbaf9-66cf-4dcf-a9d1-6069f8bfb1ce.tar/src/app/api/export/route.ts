import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// GET /api/export?format=csv - Exportar movimientos a CSV
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const tipo = searchParams.get('tipo')

    const where: Record<string, unknown> = {}
    if (tipo) where.tipo = tipo

    const movimientos = await db.movimiento.findMany({
      where,
      orderBy: { fecha: 'desc' },
    })

    // Generar CSV
    const headers = ['ID', 'Tipo', 'Concepto', 'Categoría', 'Importe', 'Fecha', 'Cuenta', 'Notas']
    const rows = movimientos.map((m) => [
      m.id,
      m.tipo,
      `"${m.concepto}"`,
      `"${m.categoria}"`,
      m.importe.toFixed(2),
      new Date(m.fecha).toISOString().split('T')[0],
      `"${m.cuenta}"`,
      m.notas ? `"${m.notas}"` : '',
    ].join(','))

    const csv = [headers.join(','), ...rows].join('\n')

    return new NextResponse(csv, {
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="smarthub_movimientos_${new Date().toISOString().split('T')[0]}.csv"`,
      },
    })
  } catch (error) {
    console.error('Error al exportar CSV:', error)
    return NextResponse.json({ error: 'Error al exportar CSV' }, { status: 500 })
  }
}
