'use client'

import { useState, useEffect, useCallback } from 'react'
import type { Section, Movimiento } from '@/lib/types'
import { seedData, exportCSV, downloadBackup, fetchCategorias, fetchCuentas } from '@/lib/api'
import { Sidebar } from '@/components/smarthub/Sidebar'
import { Dashboard } from '@/components/smarthub/Dashboard'
import { MovimientoForm } from '@/components/smarthub/MovimientoForm'
import { MovimientosList } from '@/components/smarthub/MovimientosList'
import { CuentasManager } from '@/components/smarthub/CuentasManager'
import { CategoriasManager } from '@/components/smarthub/CategoriasManager'
import { Menu } from 'lucide-react'

export default function Home() {
  const [activeSection, setActiveSection] = useState<Section>('dashboard')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [refreshKey, setRefreshKey] = useState(0)
  const [editMovimiento, setEditMovimiento] = useState<Movimiento | null>(null)
  const [ready, setReady] = useState(false)

  // Seed default data on first load
  useEffect(() => {
    seedData().then(() => setReady(true)).catch(() => setReady(true))
  }, [])

  const refresh = useCallback(() => setRefreshKey((k) => k + 1), [])

  // Navigation handler
  const navigate = (section: Section) => {
    setActiveSection(section)
    setEditMovimiento(null)
  }

  // Handle edit from movimientos list
  const handleEdit = (mov: Movimiento) => {
    setEditMovimiento(mov)
    setActiveSection(mov.tipo === 'ingreso' ? 'ingresos' : 'gastos')
  }

  const handleFormSave = () => {
    refresh()
    setEditMovimiento(null)
  }

  const handleCancelEdit = () => {
    setEditMovimiento(null)
  }

  if (!ready) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center mx-auto mb-4">
            <span className="text-2xl">💎</span>
          </div>
          <p className="text-sm text-muted-foreground">Cargando SmartHub...</p>
        </div>
      </div>
    )
  }

  const sectionTitle: Record<Section, string> = {
    dashboard: 'Dashboard',
    ingresos: 'Ingresos',
    gastos: 'Gastos',
    movimientos: 'Movimientos',
    cuentas: 'Cuentas',
    categorias: 'Categorías',
  }

  return (
    <div className="min-h-screen flex bg-background">
      {/* Sidebar */}
      <Sidebar
        activeSection={activeSection}
        onNavigate={navigate}
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        onExportCSV={() => exportCSV()}
        onBackup={() => downloadBackup()}
      />

      {/* Main content */}
      <main className="flex-1 lg:ml-64 min-h-screen">
        {/* Top bar */}
        <header className="sticky top-0 z-30 glass-strong px-4 sm:px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2 rounded-xl hover:bg-white/[0.06] text-muted-foreground hover:text-foreground transition-all"
            >
              <Menu size={20} />
            </button>
            <h1 className="text-lg font-bold hidden sm:block">{sectionTitle[activeSection]}</h1>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">
              {new Date().toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
            </span>
          </div>
        </header>

        {/* Content area */}
        <div className="p-4 sm:p-6 pb-24 lg:pb-6">
          {/* Dashboard */}
          {activeSection === 'dashboard' && (
            <Dashboard onDataRefresh={refresh} />
          )}

          {/* Ingresos */}
          {activeSection === 'ingresos' && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-bold mb-1">Ingresos</h1>
                <p className="text-sm text-muted-foreground">Registra y gestiona tus fuentes de ingresos</p>
              </div>
              <MovimientoForm
                tipoFijo="ingreso"
                editMovimiento={editMovimiento}
                onSave={handleFormSave}
                onCancelEdit={handleCancelEdit}
              />
              <MovimientosList
                initialTipo="ingreso"
                onEdit={handleEdit}
                refreshKey={refreshKey}
              />
            </div>
          )}

          {/* Gastos */}
          {activeSection === 'gastos' && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-bold mb-1">Gastos</h1>
                <p className="text-sm text-muted-foreground">Controla y registra todos tus gastos</p>
              </div>
              <MovimientoForm
                tipoFijo="gasto"
                editMovimiento={editMovimiento}
                onSave={handleFormSave}
                onCancelEdit={handleCancelEdit}
              />
              <MovimientosList
                initialTipo="gasto"
                onEdit={handleEdit}
                refreshKey={refreshKey}
              />
            </div>
          )}

          {/* Movimientos (all) */}
          {activeSection === 'movimientos' && (
            <div>
              <div className="mb-6">
                <h1 className="text-2xl font-bold mb-1">Movimientos</h1>
                <p className="text-sm text-muted-foreground">Historial completo de todos tus movimientos</p>
              </div>
              <MovimientosList
                onEdit={handleEdit}
                refreshKey={refreshKey}
              />
            </div>
          )}

          {/* Cuentas */}
          {activeSection === 'cuentas' && <CuentasManager />}

          {/* Categorías */}
          {activeSection === 'categorias' && <CategoriasManager />}
        </div>
      </main>
    </div>
  )
}