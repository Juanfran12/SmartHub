// ===== SMARTHUB API HELPERS =====
import type { Movimiento, MovimientoForm, Categoria, Cuenta, DashboardData, FiltrosMovimiento } from './types'

const API = '/api'

// Format currency EUR
export function formatMoney(n: number): string {
  return new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR' }).format(n)
}

// Format date
export function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString('es-ES', {
    day: 'numeric', month: 'short', year: 'numeric',
  })
}

// Today as YYYY-MM-DD
export function today(): string {
  return new Date().toISOString().split('T')[0]
}

// Dashboard
export async function fetchDashboard(): Promise<DashboardData> {
  const res = await fetch(`${API}/dashboard`)
  if (!res.ok) throw new Error('Error al cargar dashboard')
  return res.json()
}

// Movimientos
export async function fetchMovimientos(filtros?: Partial<FiltrosMovimiento>, page = 1, limit = 100) {
  const params = new URLSearchParams({ page: String(page), limit: String(limit) })
  if (filtros?.tipo && filtros.tipo !== 'todos') params.set('tipo', filtros.tipo)
  if (filtros?.categoria) params.set('categoria', filtros.categoria)
  if (filtros?.cuenta) params.set('cuenta', filtros.cuenta)
  if (filtros?.desde) params.set('desde', filtros.desde)
  if (filtros?.hasta) params.set('hasta', filtros.hasta)
  if (filtros?.buscar) params.set('buscar', filtros.buscar)

  const res = await fetch(`${API}/movimientos?${params}`)
  if (!res.ok) throw new Error('Error al listar movimientos')
  return res.json() as Promise<{ movimientos: Movimiento[]; total: number; page: number; limit: number }>
}

export async function createMovimiento(data: MovimientoForm): Promise<Movimiento> {
  const res = await fetch(`${API}/movimientos`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  })
  const json = await res.json()
  if (!res.ok) throw new Error(json.error || 'Error al crear movimiento')
  return json
}

export async function updateMovimiento(id: number, data: MovimientoForm): Promise<Movimiento> {
  const res = await fetch(`${API}/movimientos/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  })
  const json = await res.json()
  if (!res.ok) throw new Error(json.error || 'Error al actualizar movimiento')
  return json
}

export async function deleteMovimiento(id: number): Promise<void> {
  const res = await fetch(`${API}/movimientos/${id}`, { method: 'DELETE' })
  const json = await res.json()
  if (!res.ok) throw new Error(json.error || 'Error al eliminar movimiento')
}

// Categorías
export async function fetchCategorias(): Promise<Categoria[]> {
  const res = await fetch(`${API}/categorias`)
  if (!res.ok) throw new Error('Error al listar categorías')
  return res.json()
}

export async function createCategoria(nombre: string): Promise<Categoria> {
  const res = await fetch(`${API}/categorias`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nombre }),
  })
  const json = await res.json()
  if (!res.ok) throw new Error(json.error || 'Error al crear categoría')
  return json
}

export async function deleteCategoria(id: number): Promise<void> {
  const res = await fetch(`${API}/categorias/${id}`, { method: 'DELETE' })
  const json = await res.json()
  if (!res.ok) throw new Error(json.error || 'Error al eliminar categoría')
}

// Cuentas
export async function fetchCuentas(): Promise<Cuenta[]> {
  const res = await fetch(`${API}/cuentas`)
  if (!res.ok) throw new Error('Error al listar cuentas')
  return res.json()
}

export async function createCuenta(nombre: string, saldo = 0): Promise<Cuenta> {
  const res = await fetch(`${API}/cuentas`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nombre, saldo }),
  })
  const json = await res.json()
  if (!res.ok) throw new Error(json.error || 'Error al crear cuenta')
  return json
}

export async function updateCuenta(id: number, nombre: string, saldo: number): Promise<Cuenta> {
  const res = await fetch(`${API}/cuentas/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nombre, saldo }),
  })
  const json = await res.json()
  if (!res.ok) throw new Error(json.error || 'Error al actualizar cuenta')
  return json
}

export async function deleteCuenta(id: number): Promise<void> {
  const res = await fetch(`${API}/cuentas/${id}`, { method: 'DELETE' })
  const json = await res.json()
  if (!res.ok) throw new Error(json.error || 'Error al eliminar cuenta')
}

// Seed
export async function seedData(): Promise<void> {
  await fetch(`${API}/seed`)
}

// Export CSV
export function exportCSV(tipo?: string) {
  const params = tipo && tipo !== 'todos' ? `?tipo=${tipo}` : ''
  window.open(`${API}/export${params}`, '_blank')
}

// Backup
export function downloadBackup() {
  window.open(`${API}/backup`, '_blank')
}