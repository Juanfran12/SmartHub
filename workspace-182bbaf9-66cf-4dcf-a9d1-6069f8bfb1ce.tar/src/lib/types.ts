// ===== SMARTHUB TYPES =====

export interface Movimiento {
  id: number
  tipo: 'ingreso' | 'gasto'
  concepto: string
  categoria: string
  importe: number
  fecha: string
  cuenta: string
  notas: string | null
  createdAt: string
}

export interface Categoria {
  id: number
  nombre: string
  createdAt: string
}

export interface Cuenta {
  id: number
  nombre: string
  saldo: number
  createdAt: string
}

export interface DashboardData {
  saldoTotal: number
  totalIngresos: number
  totalGastos: number
  balanceMensual: number
  ingresosMes: number
  gastosMes: number
  cuentas: Cuenta[]
  ultimosMovimientos: Movimiento[]
  gastosPorCategoria: Record<string, number>
  ingresosPorMes: Record<string, number>
  gastosPorMes: Record<string, number>
  evolucionSaldo: Record<string, number>
}

export type Section = 'dashboard' | 'ingresos' | 'gastos' | 'movimientos' | 'cuentas' | 'categorias'

export interface MovimientoForm {
  tipo: 'ingreso' | 'gasto'
  concepto: string
  categoria: string
  importe: string
  fecha: string
  cuenta: string
  notas: string
}

export interface FiltrosMovimiento {
  tipo: string
  categoria: string
  cuenta: string
  desde: string
  hasta: string
  buscar: string
}
