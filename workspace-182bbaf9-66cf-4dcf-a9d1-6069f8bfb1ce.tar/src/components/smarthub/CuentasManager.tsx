'use client'

import { useEffect, useState } from 'react'
import { fetchCuentas, createCuenta, updateCuenta, deleteCuenta, formatMoney } from '@/lib/api'
import type { Cuenta } from '@/lib/types'
import { Wallet, Plus, Trash2, Edit3, Save, X, Loader2 } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

export function CuentasManager() {
  const { toast } = useToast()
  const [cuentas, setCuentas] = useState<Cuenta[]>([])
  const [loading, setLoading] = useState(true)
  const [showNew, setShowNew] = useState(false)
  const [newName, setNewName] = useState('')
  const [newSaldo, setNewSaldo] = useState('0')
  const [creating, setCreating] = useState(false)
  const [editing, setEditing] = useState<number | null>(null)
  const [editSaldo, setEditSaldo] = useState('')

  const load = async () => {
    try {
      setLoading(true)
      const data = await fetchCuentas()
      setCuentas(data)
    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  const handleCreate = async () => {
    if (!newName.trim()) return
    try {
      setCreating(true)
      await createCuenta(newName.trim(), parseFloat(newSaldo) || 0)
      toast({ title: '✅ Cuenta creada', description: newName })
      setNewName('')
      setNewSaldo('0')
      setShowNew(false)
      load()
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error'
      toast({ title: '❌ Error', description: msg, variant: 'destructive' })
    } finally {
      setCreating(false)
    }
  }

  const handleUpdateSaldo = async (id: number) => {
    const cuenta = cuentas.find((c) => c.id === id)
    if (!cuenta) return
    try {
      await updateCuenta(id, cuenta.nombre, parseFloat(editSaldo))
      toast({ title: '✅ Saldo actualizado' })
      setEditing(null)
      load()
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error'
      toast({ title: '❌ Error', description: msg, variant: 'destructive' })
    }
  }

  const handleDelete = async (id: number, nombre: string) => {
    if (!confirm(`¿Eliminar la cuenta "${nombre}"?`)) return
    try {
      await deleteCuenta(id)
      toast({ title: '🗑️ Cuenta eliminada' })
      load()
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error'
      toast({ title: '❌ Error', description: msg, variant: 'destructive' })
    }
  }

  const totalSaldo = cuentas.reduce((s, c) => s + c.saldo, 0)

  const inputCls = 'w-full bg-white/[0.06] border border-white/[0.08] rounded-xl px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all'

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Cuentas</h1>
          <p className="text-sm text-muted-foreground mt-1">Gestiona tus cuentas bancarias y monederos</p>
        </div>
        <button
          onClick={() => setShowNew(!showNew)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium bg-blue-500/15 text-blue-400 border border-blue-500/30 hover:bg-blue-500/25 transition-all duration-200"
        >
          <Plus size={16} /> Nueva Cuenta
        </button>
      </div>

      {/* Total */}
      <div className="glass rounded-2xl p-5 glow-blue">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-blue-500/15 flex items-center justify-center">
            <Wallet size={24} className="text-blue-400" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-wider">Saldo Total</p>
            <p className={`text-2xl font-bold ${totalSaldo >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              {formatMoney(totalSaldo)}
            </p>
          </div>
        </div>
      </div>

      {/* New account form */}
      {showNew && (
        <div className="glass rounded-2xl p-5 animate-scale-in">
          <h3 className="text-sm font-semibold mb-4">Nueva Cuenta</h3>
          <div className="flex flex-col sm:flex-row gap-3">
            <input
              type="text" placeholder="Nombre de la cuenta"
              value={newName} onChange={(e) => setNewName(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleCreate()}
              className={inputCls + ' flex-1'}
            />
            <input
              type="number" step="0.01" placeholder="Saldo inicial"
              value={newSaldo} onChange={(e) => setNewSaldo(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleCreate()}
              className={inputCls + ' w-full sm:w-40'}
            />
            <div className="flex gap-2">
              <button
                onClick={handleCreate} disabled={creating || !newName.trim()}
                className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/25 transition-all disabled:opacity-50"
              >
                {creating ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />} Crear
              </button>
              <button
                onClick={() => { setShowNew(false); setNewName(''); setNewSaldo('0') }}
                className="p-2 rounded-xl text-muted-foreground hover:text-foreground hover:bg-white/[0.04] transition-all"
              >
                <X size={16} />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Accounts list */}
      {loading ? (
        <div className="flex justify-center py-16"><Loader2 size={24} className="animate-spin text-muted-foreground" /></div>
      ) : cuentas.length === 0 ? (
        <div className="glass rounded-2xl p-12 text-center">
          <Wallet size={40} className="mx-auto text-muted-foreground/30 mb-3" />
          <p className="text-muted-foreground text-sm">No hay cuentas creadas</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 stagger-children">
          {cuentas.map((c) => (
            <div key={c.id} className="glass rounded-2xl p-5 group hover:bg-white/[0.03] transition-all duration-200">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${c.saldo >= 0 ? 'bg-emerald-500/10' : 'bg-red-500/10'}`}>
                    <Wallet size={18} className={c.saldo >= 0 ? 'text-emerald-400' : 'text-red-400'} />
                  </div>
                  <h3 className="font-semibold text-sm">{c.nombre}</h3>
                </div>
                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  {editing === c.id ? (
                    <button onClick={() => handleUpdateSaldo(c.id)} className="p-1.5 rounded-lg hover:bg-emerald-500/10 text-emerald-400 transition-colors">
                      <Save size={14} />
                    </button>
                  ) : (
                    <button onClick={() => { setEditing(c.id); setEditSaldo(String(c.saldo)) }} className="p-1.5 rounded-lg hover:bg-white/[0.08] text-muted-foreground hover:text-blue-400 transition-colors">
                      <Edit3 size={14} />
                    </button>
                  )}
                  <button onClick={() => handleDelete(c.id, c.nombre)} className="p-1.5 rounded-lg hover:bg-red-500/10 text-muted-foreground hover:text-red-400 transition-colors">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
              {editing === c.id ? (
                <input
                  type="number" step="0.01" value={editSaldo}
                  onChange={(e) => setEditSaldo(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleUpdateSaldo(c.id)}
                  onBlur={() => setEditing(null)}
                  autoFocus
                  className="w-full bg-white/[0.06] border border-blue-500/30 rounded-xl px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-blue-500/30"
                />
              ) : (
                <p className={`text-xl font-bold ${c.saldo >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                  {formatMoney(c.saldo)}
                </p>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}