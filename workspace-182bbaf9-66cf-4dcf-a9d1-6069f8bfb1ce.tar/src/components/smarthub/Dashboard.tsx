'use client'

import { useEffect, useState } from 'react'
import { formatMoney, fetchDashboard } from '@/lib/api'
import type { DashboardData } from '@/lib/types'
import {
  TrendingUp, TrendingDown, Wallet, ArrowUpRight, ArrowDownRight
} from 'lucide-react'
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell, Area, AreaChart, CartesianGrid
} from 'recharts'

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ef4444', '#06b6d4', '#ec4899', '#84cc16', '#f97316', '#6366f1', '#14b8a6', '#e11d48', '#a855f7']

interface DashboardProps {
  onDataRefresh: () => void
}

export function Dashboard({ onDataRefresh }: DashboardProps) {
  const [data, setData] = useState<DashboardData | null>(null)
  const [loading, setLoading] = useState(true)

  const load = async () => {
    try {
      setLoading(true)
      const d = await fetchDashboard()
      setData(d)
      onDataRefresh()
    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  if (loading || !data) {
    return (
      <div className="space-y-6 animate-fade-in">
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="glass rounded-2xl p-6 h-28 animate-pulse bg-white/[0.03]" />
          ))}
        </div>
        <div className="glass rounded-2xl p-6 h-72 animate-pulse bg-white/[0.03]" />
      </div>
    )
  }

  // Transform data for charts
  const gastosCategoriaData = Object.entries(data.gastosPorCategoria).map(([name, value]) => ({ name, value: Math.round(value * 100) / 100 }))
  const ingresosMesData = Object.entries(data.ingresosPorMes).map(([name, value]) => ({ name, value: Math.round(value * 100) / 100 }))
  const gastosMesData = Object.entries(data.gastosPorMes).map(([name, value]) => ({ name, value: Math.round(value * 100) / 100 }))
  const evolucionData = Object.entries(data.evolucionSaldo).map(([name, value]) => ({ name, value }))

  // Merge ingresos/gastos mes for comparative chart
  const mesesComparativa = Object.keys(data.ingresosPorMes)
  const comparativaData = mesesComparativa.map((m) => ({
    name: m,
    Ingresos: Math.round((data.ingresosPorMes[m] || 0) * 100) / 100,
    Gastos: Math.round((data.gastosPorMes[m] || 0) * 100) / 100,
  }))

  const CustomTooltip = ({ active, payload, label }: { active?: boolean; payload?: Array<{ name: string; value: number; color: string }>; label?: string }) => {
    if (active && payload && payload.length) {
      return (
        <div className="glass-strong rounded-lg px-3 py-2 text-xs">
          <p className="text-muted-foreground mb-1">{label}</p>
          {payload.map((p, i) => (
            <p key={i} style={{ color: p.color }} className="font-medium">
              {p.name}: {formatMoney(p.value)}
            </p>
          ))}
        </div>
      )
    }
    return null
  }

  const PieTooltip = ({ active, payload }: { active?: boolean; payload?: Array<{ name: string; value: number; payload: { name: string; value: number } }> }) => {
    if (active && payload && payload.length) {
      return (
        <div className="glass-strong rounded-lg px-3 py-2 text-xs">
          <p className="font-medium">{payload[0].payload.name}</p>
          <p className="text-muted-foreground">{formatMoney(payload[0].payload.value)}</p>
        </div>
      )
    }
    return null
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <button onClick={load} className="text-xs text-muted-foreground hover:text-foreground transition-colors px-3 py-1.5 rounded-lg hover:bg-white/[0.04]">
          Actualizar
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 stagger-children">
        <StatCard
          label="Saldo Total"
          value={formatMoney(data.saldoTotal)}
          icon={<Wallet size={22} className="text-blue-400" />}
          glow="glow-blue"
          positive={data.saldoTotal >= 0}
        />
        <StatCard
          label="Total Ingresos"
          value={formatMoney(data.totalIngresos)}
          icon={<ArrowUpRight size={22} className="text-emerald-400" />}
          glow="glow-green"
          positive={true}
          sublabel={`Este mes: ${formatMoney(data.ingresosMes)}`}
        />
        <StatCard
          label="Total Gastos"
          value={formatMoney(data.totalGastos)}
          icon={<ArrowDownRight size={22} className="text-red-400" />}
          glow="glow-red"
          positive={false}
          sublabel={`Este mes: ${formatMoney(data.gastosMes)}`}
        />
        <StatCard
          label="Balance Mensual"
          value={formatMoney(data.balanceMensual)}
          icon={data.balanceMensual >= 0 ? <TrendingUp size={22} className="text-emerald-400" /> : <TrendingDown size={22} className="text-red-400" />}
          glow={data.balanceMensual >= 0 ? 'glow-green' : 'glow-red'}
          positive={data.balanceMensual >= 0}
        />
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Gastos por categoría */}
        <ChartCard title="Gastos por Categoría">
          {gastosCategoriaData.length > 0 ? (
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie
                  data={gastosCategoriaData}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={90}
                  paddingAngle={3}
                  dataKey="value"
                  stroke="none"
                >
                  {gastosCategoriaData.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip content={<PieTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[260px] flex items-center justify-center text-muted-foreground text-sm">
              No hay gastos este mes
            </div>
          )}
          {gastosCategoriaData.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-2 px-2">
              {gastosCategoriaData.map((d, i) => (
                <span key={d.name} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                  {d.name}
                </span>
              ))}
            </div>
          )}
        </ChartCard>

        {/* Comparativa mensual */}
        <ChartCard title="Comparativa Mensual">
          {comparativaData.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={comparativaData} barGap={4}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="name" tick={{ fill: '#8888a0', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#8888a0', fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="Ingresos" fill="#10b981" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Gastos" fill="#ef4444" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[300px] flex items-center justify-center text-muted-foreground text-sm">
              No hay datos mensuales
            </div>
          )}
        </ChartCard>

        {/* Evolución del saldo */}
        <ChartCard title="Evolución del Saldo">
          {evolucionData.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={evolucionData}>
                <defs>
                  <linearGradient id="saldoGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="name" tick={{ fill: '#8888a0', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#8888a0', fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="value" stroke="#3b82f6" strokeWidth={2} fill="url(#saldoGradient)" name="Saldo" />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[300px] flex items-center justify-center text-muted-foreground text-sm">
              No hay datos de evolución
            </div>
          )}
        </ChartCard>

        {/* Ingresos por mes */}
        <ChartCard title="Ingresos por Mes">
          {ingresosMesData.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={ingresosMesData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="name" tick={{ fill: '#8888a0', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#8888a0', fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="value" fill="#10b981" radius={[6, 6, 0, 0]} name="Ingresos" />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[300px] flex items-center justify-center text-muted-foreground text-sm">
              No hay ingresos registrados
            </div>
          )}
        </ChartCard>
      </div>

      {/* Cuentas */}
      <ChartCard title="Mis Cuentas">
        {data.cuentas.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3">
            {data.cuentas.map((c) => (
              <div key={c.id} className="glass rounded-xl p-4 flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{c.nombre}</p>
                  <p className={`text-lg font-bold ${c.saldo >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {formatMoney(c.saldo)}
                  </p>
                </div>
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${c.saldo >= 0 ? 'bg-emerald-500/10' : 'bg-red-500/10'}`}>
                  <Wallet size={18} className={c.saldo >= 0 ? 'text-emerald-400' : 'text-red-400'} />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-muted-foreground text-sm text-center py-4">No hay cuentas configuradas</p>
        )}
      </ChartCard>

      {/* Últimos movimientos */}
      <ChartCard title="Últimos Movimientos">
        {data.ultimosMovimientos.length > 0 ? (
          <div className="space-y-2">
            {data.ultimosMovimientos.map((m) => (
              <div key={m.id} className="flex items-center justify-between py-2.5 px-3 rounded-xl hover:bg-white/[0.03] transition-colors">
                <div className="flex items-center gap-3">
                  <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${m.tipo === 'ingreso' ? 'bg-emerald-500/10' : 'bg-red-500/10'}`}>
                    {m.tipo === 'ingreso' ? <TrendingUp size={16} className="text-emerald-400" /> : <TrendingDown size={16} className="text-red-400" />}
                  </div>
                  <div>
                    <p className="text-sm font-medium">{m.concepto}</p>
                    <p className="text-xs text-muted-foreground">{m.categoria} · {new Date(m.fecha).toLocaleDateString('es-ES', { day: 'numeric', month: 'short' })}</p>
                  </div>
                </div>
                <span className={`text-sm font-semibold ${m.tipo === 'ingreso' ? 'text-emerald-400' : 'text-red-400'}`}>
                  {m.tipo === 'ingreso' ? '+' : '-'}{formatMoney(m.importe)}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-muted-foreground text-sm text-center py-8">No hay movimientos registrados</p>
        )}
      </ChartCard>
    </div>
  )
}

// ===== Sub-components =====

function StatCard({ label, value, icon, glow, positive, sublabel }: {
  label: string
  value: string
  icon: React.ReactNode
  glow: string
  positive: boolean
  sublabel?: string
}) {
  return (
    <div className={`glass rounded-2xl p-5 ${glow} transition-all duration-300 hover:scale-[1.02]`}>
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{label}</span>
        {icon}
      </div>
      <p className={`text-2xl font-bold ${positive ? 'text-emerald-400' : 'text-red-400'}`}>{value}</p>
      {sublabel && <p className="text-xs text-muted-foreground mt-1">{sublabel}</p>}
    </div>
  )
}

function ChartCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="glass rounded-2xl p-5 animate-scale-in">
      <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">{title}</h3>
      {children}
    </div>
  )
}
