'use client'

import { useState, useEffect } from 'react'
import { today, createMovimiento, updateMovimiento, fetchCategorias, fetchCuentas } from '@/lib/api'
import type { MovimientoForm as MovForm, Movimiento, Categoria, Cuenta } from '@/lib/types'
import { Plus, Save, X, Loader2 } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

const emptyForm: MovForm = {
  tipo: 'gasto',
  concepto: '',
  categoria: '',
  importe: '',
  fecha: today(),
  cuenta: '',
  notas: '',
}

interface MovimientoFormProps {
  tipoFijo: 'ingreso' | 'gasto' | null
  editMovimiento?: Movimiento | null
  onSave: () => void
  onCancelEdit?: () => void
}

export function MovimientoForm({ tipoFijo, editMovimiento, onSave, onCancelEdit }: MovimientoFormProps) {
  const { toast } = useToast()
  const [form, setForm] = useState<MovForm>(emptyForm)
  const [categorias, setCategorias] = useState<Categoria[]>([])
  const [cuentas, setCuentas] = useState<Cuenta[]>([])
  const [loading, setLoading] = useState(false)
  const [errors, setErrors] = useState<Partial<Record<keyof MovForm, string>>>({})
  const [showNewCat, setShowNewCat] = useState(false)
  const [newCatName, setNewCatName] = useState('')

  useEffect(() => {
    fetchCategorias().then(setCategorias).catch(() => {})
    fetchCuentas().then(setCuentas).catch(() => {})
  }, [])

  useEffect(() => {
    if (editMovimiento) {
      setForm({
        tipo: editMovimiento.tipo,
        concepto: editMovimiento.concepto,
        categoria: editMovimiento.categoria,
        importe: String(editMovimiento.importe),
        fecha: new Date(editMovimiento.fecha).toISOString().split('T')[0],
        cuenta: editMovimiento.cuenta,
        notas: editMovimiento.notas || '',
      })
    }
  }, [editMovimiento])

  const validate = (): boolean => {
    const e: typeof errors = {}
    if (!form.concepto.trim()) e.concepto = 'Concepto obligatorio'
    if (!form.categoria) e.categoria = 'Categoría obligatoria'
    if (!form.importe || parseFloat(form.importe) <= 0) e.importe = 'Importe debe ser mayor que 0'
    if (!form.fecha) e.fecha = 'Fecha obligatoria'
    if (!form.cuenta) e.cuenta = 'Cuenta obligatoria'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  const handleSubmit = async () => {
    if (!validate()) return
    try {
      setLoading(true)
      const data = { ...form, importe: form.importe, tipo: tipoFijo || form.tipo }
      if (editMovimiento) {
        await updateMovimiento(editMovimiento.id, data)
        toast({ title: '✅ Movimiento actualizado', description: form.concepto })
      } else {
        await createMovimiento(data)
        toast({ title: `✅ ${data.tipo === 'ingreso' ? 'Ingreso' : 'Gasto'} registrado`, description: form.concepto })
      }
      setForm({ ...emptyForm, tipo: tipoFijo || form.tipo, fecha: today() })
      onSave()
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error desconocido'
      toast({ title: '❌ Error', description: msg, variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  const handleAddCategoria = async () => {
    if (!newCatName.trim()) return
    try {
      const { createCategoria } = await import('@/lib/api')
      const cat = await createCategoria(newCatName.trim())
      setCategorias((prev) => [...prev, cat])
      setForm((prev) => ({ ...prev, categoria: cat.nombre }))
      setNewCatName('')
      setShowNewCat(false)
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error'
      toast({ title: '❌ Error', description: msg, variant: 'destructive' })
    }
  }

  const inputClass = (field: keyof MovForm) =>
    `w-full bg-white/[0.06] border ${errors[field] ? 'border-red-500/50' : 'border-white/[0.08]'} rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500/50 transition-all duration-200`

  const isEdit = !!editMovimiento
  const tipo = tipoFijo || form.tipo

  return (
    <div className="glass rounded-2xl p-6 animate-fade-in">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-bold flex items-center gap-2">
          {isEdit ? 'Editar Movimiento' : tipoFijo === 'ingreso' ? 'Nuevo Ingreso' : tipoFijo === 'gasto' ? 'Nuevo Gasto' : 'Nuevo Movimiento'}
        </h2>
        {isEdit && onCancelEdit && (
          <button onClick={onCancelEdit} className="text-muted-foreground hover:text-foreground transition-colors p-1">
            <X size={18} />
          </button>
        )}
      </div>

      {/* Type toggle (only if no tipoFijo) */}
      {!tipoFijo && (
        <div className="flex gap-2 mb-5">
          <button
            onClick={() => setForm({ ...form, tipo: 'ingreso' })}
            className={`flex-1 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 ${
              form.tipo === 'ingreso'
                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                : 'bg-white/[0.04] text-muted-foreground border border-transparent hover:bg-white/[0.06]'
            }`}
          >
            💰 Ingreso
          </button>
          <button
            onClick={() => setForm({ ...form, tipo: 'gasto' })}
            className={`flex-1 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 ${
              form.tipo === 'gasto'
                ? 'bg-red-500/15 text-red-400 border border-red-500/30'
                : 'bg-white/[0.04] text-muted-foreground border border-transparent hover:bg-white/[0.06]'
            }`}
          >
            💸 Gasto
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Concepto */}
        <div className="sm:col-span-2">
          <label className="block text-xs text-muted-foreground mb-1.5 font-medium">Concepto *</label>
          <input
            type="text" placeholder="Ej: Nómina, Alquiler, Comida..."
            value={form.concepto} onChange={(e) => setForm({ ...form, concepto: e.target.value })}
            className={inputClass('concepto')}
          />
          {errors.concepto && <p className="text-xs text-red-400 mt-1">{errors.concepto}</p>}
        </div>

        {/* Categoría */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs text-muted-foreground font-medium">Categoría *</label>
            {!showNewCat && (
              <button onClick={() => setShowNewCat(true)} className="text-xs text-blue-400 hover:text-blue-300 transition-colors">
                + Nueva
              </button>
            )}
          </div>
          {showNewCat ? (
            <div className="flex gap-2">
              <input
                type="text" placeholder="Nombre..." value={newCatName}
                onChange={(e) => setNewCatName(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddCategoria()}
                className="flex-1 bg-white/[0.06] border border-white/[0.08] rounded-xl px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-blue-500/30"
              />
              <button onClick={handleAddCategoria} className="px-3 py-2.5 bg-blue-500/20 text-blue-400 rounded-xl text-sm hover:bg-blue-500/30 transition-colors">
                OK
              </button>
              <button onClick={() => { setShowNewCat(false); setNewCatName('') }} className="px-2 py-2.5 text-muted-foreground hover:text-foreground transition-colors">
                <X size={16} />
              </button>
            </div>
          ) : (
            <select
              value={form.categoria} onChange={(e) => setForm({ ...form, categoria: e.target.value })}
              className={inputClass('categoria')}
            >
              <option value="">Seleccionar...</option>
              {categorias.map((c) => <option key={c.id} value={c.nombre}>{c.nombre}</option>)}
            </select>
          )}
          {errors.categoria && <p className="text-xs text-red-400 mt-1">{errors.categoria}</p>}
        </div>

        {/* Importe */}
        <div>
          <label className="block text-xs text-muted-foreground mb-1.5 font-medium">Importe (€) *</label>
          <input
            type="number" step="0.01" min="0" placeholder="0.00"
            value={form.importe} onChange={(e) => setForm({ ...form, importe: e.target.value })}
            className={inputClass('importe')}
          />
          {errors.importe && <p className="text-xs text-red-400 mt-1">{errors.importe}</p>}
        </div>

        {/* Fecha */}
        <div>
          <label className="block text-xs text-muted-foreground mb-1.5 font-medium">Fecha *</label>
          <input
            type="date" value={form.fecha}
            onChange={(e) => setForm({ ...form, fecha: e.target.value })}
            className={inputClass('fecha')}
          />
          {errors.fecha && <p className="text-xs text-red-400 mt-1">{errors.fecha}</p>}
        </div>

        {/* Cuenta */}
        <div>
          <label className="block text-xs text-muted-foreground mb-1.5 font-medium">Cuenta *</label>
          <select
            value={form.cuenta} onChange={(e) => setForm({ ...form, cuenta: e.target.value })}
            className={inputClass('cuenta')}
          >
            <option value="">Seleccionar...</option>
            {cuentas.map((c) => <option key={c.id} value={c.nombre}>{c.nombre}</option>)}
          </select>
          {errors.cuenta && <p className="text-xs text-red-400 mt-1">{errors.cuenta}</p>}
        </div>

        {/* Notas */}
        <div className="sm:col-span-2">
          <label className="block text-xs text-muted-foreground mb-1.5 font-medium">Notas</label>
          <textarea
            placeholder="Notas opcionales..."
            value={form.notas} onChange={(e) => setForm({ ...form, notas: e.target.value })}
            rows={2}
            className={inputClass('notas') + ' resize-none'}
          />
        </div>
      </div>

      {/* Submit */}
      <button
        onClick={handleSubmit} disabled={loading}
        className={`mt-5 w-full py-3 rounded-xl font-medium text-sm flex items-center justify-center gap-2 transition-all duration-200 ${
          isEdit
            ? 'bg-blue-500/20 text-blue-400 hover:bg-blue-500/30 border border-blue-500/30'
            : tipo === 'ingreso'
              ? 'bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 border border-emerald-500/30'
              : 'bg-red-500/20 text-red-400 hover:bg-red-500/30 border border-red-500/30'
        } disabled:opacity-50 disabled:cursor-not-allowed`}
      >
        {loading ? <Loader2 size={16} className="animate-spin" /> : isEdit ? <Save size={16} /> : <Plus size={16} />}
        {loading ? 'Guardando...' : isEdit ? 'Guardar Cambios' : tipo === 'ingreso' ? 'Registrar Ingreso' : 'Registrar Gasto'}
      </button>
    </div>
  )
}