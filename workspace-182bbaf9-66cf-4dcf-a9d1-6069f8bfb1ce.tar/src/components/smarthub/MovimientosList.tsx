'use client'

import { useEffect, useState, useCallback } from 'react'
import { fetchMovimientos, deleteMovimiento, formatMoney, formatDate, fetchCategorias, fetchCuentas } from '@/lib/api'
import type { Movimiento, FiltrosMovimiento, Categoria, Cuenta } from '@/lib/types'
import { TrendingUp, TrendingDown, Search, Trash2, Edit3, Filter, ChevronDown, X, Loader2 } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface MovimientosListProps {
  onEdit?: (mov: Movimiento) => void
  initialTipo?: string
  refreshKey?: number
}

export function MovimientosList({ onEdit, initialTipo, refreshKey }: MovimientosListProps) {
  const { toast } = useToast()
  const [movimientos, setMovimientos] = useState<Movimiento[]>([])
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(true)
  const [categorias, setCategorias] = useState<Categoria[]>([])
  const [cuentas, setCuentas] = useState<Cuenta[]>([])
  const [filtros, setFiltros] = useState<FiltrosMovimiento>({
    tipo: initialTipo || 'todos',
    categoria: '',
    cuenta: '',
    desde: '',
    hasta: '',
    buscar: '',
  })
  const [showFilters, setShowFilters] = useState(false)
  const [deleting, setDeleting] = useState<number | null>(null)
  const [page, setPage] = useState(1)

  const load = useCallback(async () => {
    try {
      setLoading(true)
      const res = await fetchMovimientos(filtros, page, 100)
      setMovimientos(res.movimientos)
      setTotal(res.total)
    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }, [filtros, page])

  useEffect(() => { load() }, [load, refreshKey])

  useEffect(() => {
    fetchCategorias().then(setCategorias).catch(() => {})
    fetchCuentas().then(setCuentas).catch(() => {})
  }, [])

  const handleDelete = async (id: number, concepto: string) => {
    if (!confirm(`¿Eliminar "${concepto}"?`)) return
    try {
      setDeleting(id)
      await deleteMovimiento(id)
      toast({ title: '🗑️ Movimiento eliminado' })
      load()
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error'
      toast({ title: '❌ Error', description: msg, variant: 'destructive' })
    } finally {
      setDeleting(null)
    }
  }

  const clearFiltros = () => {
    setFiltros({ tipo: initialTipo || 'todos', categoria: '', cuenta: '', desde: '', hasta: '', buscar: '' })
    setPage(1)
  }

  const hasActiveFilters = filtros.tipo !== 'todos' || filtros.categoria || filtros.cuenta || filtros.desde || filtros.hasta || filtros.buscar

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold">Movimientos</h2>
        <span className="text-xs text-muted-foreground">{total} resultado{total !== 1 ? 's' : ''}</span>
      </div>

      {/* Search + Filter toggle */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text" placeholder="Buscar movimientos..."
            value={filtros.buscar} onChange={(e) => { setFiltros({ ...filtros, buscar: e.target.value }); setPage(1) }}
            className="w-full bg-white/[0.06] border border-white/[0.08] rounded-xl pl-10 pr-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500/50 transition-all"
          />
          {filtros.buscar && (
            <button onClick={() => { setFiltros({ ...filtros, buscar: '' }); setPage(1) }} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
              <X size={14} />
            </button>
          )}
        </div>
        <button
          onClick={() => setShowFilters(!showFilters)}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 border ${
            showFilters || hasActiveFilters
              ? 'bg-blue-500/15 text-blue-400 border-blue-500/30'
              : 'bg-white/[0.04] text-muted-foreground border-white/[0.08] hover:bg-white/[0.06]'
          }`}
        >
          <Filter size={16} /> Filtros {hasActiveFilters && <span className="w-2 h-2 rounded-full bg-blue-400" />}
        </button>
      </div>

      {/* Filters panel */}
      {showFilters && (
        <div className="glass rounded-2xl p-4 animate-scale-in">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            <div>
              <label className="block text-xs text-muted-foreground mb-1.5">Tipo</label>
              <select
                value={filtros.tipo} onChange={(e) => { setFiltros({ ...filtros, tipo: e.target.value }); setPage(1) }}
                className="w-full bg-white/[0.06] border border-white/[0.08] rounded-xl px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-blue-500/30"
              >
                <option value="todos">Todos</option>
                <option value="ingreso">Ingresos</option>
                <option value="gasto">Gastos</option>
              </select>
            </div>
            <div>
              <label className="block text-xs text-muted-foreground mb-1.5">Categoría</label>
              <select
                value={filtros.categoria} onChange={(e) => { setFiltros({ ...filtros, categoria: e.target.value }); setPage(1) }}
                className="w-full bg-white/[0.06] border border-white/[0.08] rounded-xl px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-blue-500/30"
              >
                <option value="">Todas</option>
                {categorias.map((c) => <option key={c.id} value={c.nombre}>{c.nombre}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs text-muted-foreground mb-1.5">Cuenta</label>
              <select
                value={filtros.cuenta} onChange={(e) => { setFiltros({ ...filtros, cuenta: e.target.value }); setPage(1) }}
                className="w-full bg-white/[0.06] border border-white/[0.08] rounded-xl px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-blue-500/30"
              >
                <option value="">Todas</option>
                {cuentas.map((c) => <option key={c.id} value={c.nombre}>{c.nombre}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs text-muted-foreground mb-1.5">Desde</label>
              <input
                type="date" value={filtros.desde}
                onChange={(e) => { setFiltros({ ...filtros, desde: e.target.value }); setPage(1) }}
                className="w-full bg-white/[0.06] border border-white/[0.08] rounded-xl px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-blue-500/30"
              />
            </div>
            <div>
              <label className="block text-xs text-muted-foreground mb-1.5">Hasta</label>
              <input
                type="date" value={filtros.hasta}
                onChange={(e) => { setFiltros({ ...filtros, hasta: e.target.value }); setPage(1) }}
                className="w-full bg-white/[0.06] border border-white/[0.08] rounded-xl px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-blue-500/30"
              />
            </div>
          </div>
          {hasActiveFilters && (
            <button onClick={clearFiltros} className="mt-3 text-xs text-blue-400 hover:text-blue-300 transition-colors">
              Limpiar filtros
            </button>
          )}
        </div>
      )}

      {/* List */}
      <div className="space-y-2 max-h-[calc(100vh-320px)] overflow-y-auto pr-1">
        {loading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 size={24} className="animate-spin text-muted-foreground" />
          </div>
        ) : movimientos.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-muted-foreground text-sm">No se encontraron movimientos</p>
          </div>
        ) : (
          <div className="stagger-children space-y-2">
            {movimientos.map((m) => (
              <div
                key={m.id}
                className={`glass rounded-xl p-4 flex items-center justify-between group hover:bg-white/[0.03] transition-all duration-200 ${
                  m.tipo === 'ingreso' ? 'border-l-2 border-l-emerald-500/50' : 'border-l-2 border-l-red-500/50'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                    m.tipo === 'ingreso' ? 'bg-emerald-500/10' : 'bg-red-500/10'
                  }`}
                  >
                    {m.tipo === 'ingreso'
                      ? <TrendingUp size={18} className="text-emerald-400" />
                      : <TrendingDown size={18} className="text-red-400" />
                    }
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate">{m.concepto}</p>
                    <p className="text-xs text-muted-foreground truncate">
                      {m.categoria} · {m.cuenta} · {formatDate(m.fecha)}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`text-sm font-bold whitespace-nowrap ${
                    m.tipo === 'ingreso' ? 'text-emerald-400' : 'text-red-400'
                  }`}>
                    {m.tipo === 'ingreso' ? '+' : '-'}{formatMoney(m.importe)}
                  </span>
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    {onEdit && (
                      <button
                        onClick={() => onEdit(m)}
                        className="p-1.5 rounded-lg hover:bg-white/[0.08] text-muted-foreground hover:text-blue-400 transition-colors"
                      >
                        <Edit3 size={14} />
                      </button>
                    )}
                    <button
                      onClick={() => handleDelete(m.id, m.concepto)}
                      disabled={deleting === m.id}
                      className="p-1.5 rounded-lg hover:bg-red-500/10 text-muted-foreground hover:text-red-400 transition-colors"
                    >
                      {deleting === m.id ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}