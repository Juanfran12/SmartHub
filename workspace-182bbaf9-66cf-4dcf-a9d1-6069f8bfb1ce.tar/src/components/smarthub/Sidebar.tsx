'use client'

import { type Section } from '@/lib/types'
import {
  LayoutDashboard, TrendingUp, TrendingDown, List, Wallet, Tags,
  Download, Database, X, Gem
} from 'lucide-react'

const navItems: { id: Section; label: string; icon: React.ReactNode }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={20} /> },
  { id: 'ingresos', label: 'Ingresos', icon: <TrendingUp size={20} /> },
  { id: 'gastos', label: 'Gastos', icon: <TrendingDown size={20} /> },
  { id: 'movimientos', label: 'Movimientos', icon: <List size={20} /> },
  { id: 'cuentas', label: 'Cuentas', icon: <Wallet size={20} /> },
  { id: 'categorias', label: 'Categorías', icon: <Tags size={20} /> },
]

interface SidebarProps {
  activeSection: Section
  onNavigate: (section: Section) => void
  open: boolean
  onClose: () => void
  onExportCSV: () => void
  onBackup: () => void
}

export function Sidebar({ activeSection, onNavigate, open, onClose, onExportCSV, onBackup }: SidebarProps) {
  return (
    <>
      {/* Mobile overlay */}
      {open && (
        <div
          className="fixed inset-0 bg-black/60 z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed top-0 left-0 h-full z-50 w-64 glass-strong flex flex-col transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          open ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Logo */}
        <div className="flex items-center justify-between p-6 border-b border-white/[0.06]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-500/20 flex items-center justify-center">
              <Gem size={20} className="text-blue-400" />
            </div>
            <span className="text-lg font-bold tracking-tight">SmartHub</span>
          </div>
          <button onClick={onClose} className="lg:hidden text-muted-foreground hover:text-foreground transition-colors">
            <X size={20} />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 py-4 px-3 space-y-1 overflow-y-auto">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => { onNavigate(item.id); onClose() }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 ${
                activeSection === item.id
                  ? 'bg-blue-500/15 text-blue-400 shadow-[0_0_15px_rgba(59,130,246,0.1)]'
                  : 'text-muted-foreground hover:text-foreground hover:bg-white/[0.04]'
              }`}
            >
              {item.icon}
              {item.label}
            </button>
          ))}
        </nav>

        {/* Actions */}
        <div className="p-3 border-t border-white/[0.06] space-y-1">
          <button
            onClick={onExportCSV}
            className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm text-muted-foreground hover:text-foreground hover:bg-white/[0.04] transition-all duration-200"
          >
            <Download size={18} />
            Exportar CSV
          </button>
          <button
            onClick={onBackup}
            className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm text-muted-foreground hover:text-foreground hover:bg-white/[0.04] transition-all duration-200"
          >
            <Database size={18} />
            Copia de seguridad
          </button>
        </div>
      </aside>
    </>
  )
}
