'use client'

import { useEffect, useState } from 'react'
import { fetchCategorias, createCategoria, deleteCategoria } from '@/lib/api'
import type { Categoria } from '@/lib/types'
import { Tags, Plus, Trash2, X, Loader2 } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

export function CategoriasManager() {
  const { toast } = useToast()
  const [categorias, setCategorias] = useState<Categoria[]>([])
  const [loading, setLoading] = useState(true)
  const [showNew, setShowNew] = useState(false)
  const [newName, setNewName] = useState('')
  const [creating, setCreating] = useState(false)

  const load = async () => {
    try {
      setLoading(true)
      const data = await fetchCategorias()
      setCategorias(data)
    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  const handleCreate = async () => {
    if (!newName.trim()) return
    try {
      setCreating(true)
      await createCategoria(newName.trim())
      toast({ title: '✅ Categoría creada', description: newName })
      setNewName('')
      setShowNew(false)
      load()
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error'
      toast({ title: '❌ Error', description: msg, variant: 'destructive' })
    } finally {
      setCreating(false)
    }
  }

  const handleDelete = async (id: number, nombre: string) => {
    if (!confirm(`¿Eliminar la categoría "${nombre}"?`)) return
    try {
      await deleteCategoria(id)
      toast({ title: '🗑️ Categoría eliminada' })
      load()
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error'
      toast({ title: '❌ Error', description: msg, variant: 'destructive' })
    }
  }

  const inputCls = 'w-full bg-white/[0.06] border border-white/[0.08] rounded-xl px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all'

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Categorías</h1>
          <p className="text-sm text-muted-foreground mt-1">Organiza tus ingresos y gastos por categoría</p>
        </div>
        <button
          onClick={() => setShowNew(!showNew)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium bg-blue-500/15 text-blue-400 border border-blue-500/30 hover:bg-blue-500/25 transition-all duration-200"
        >
          <Plus size={16} /> Nueva Categoría
        </button>
      </div>

      {/* New category form */}
      {showNew && (
        <div className="glass rounded-2xl p-5 animate-scale-in">
          <h3 className="text-sm font-semibold mb-4">Nueva Categoría</h3>
          <div className="flex gap-3">
            <input
              type="text" placeholder="Nombre de la categoría"
              value={newName} onChange={(e) => setNewName(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleCreate()}
              className={inputCls + ' flex-1'}
            />
            <button
              onClick={handleCreate} disabled={creating || !newName.trim()}
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/25 transition-all disabled:opacity-50"
            >
              {creating ? <Loader2 size={14} className="animate-spin" /> : <Plus size={14} />} Crear
            </button>
            <button
              onClick={() => { setShowNew(false); setNewName('') }}
              className="p-2 rounded-xl text-muted-foreground hover:text-foreground hover:bg-white/[0.04] transition-all"
            >
              <X size={16} />
            </button>
          </div>
        </div>
      )}

      {/* Categories grid */}
      {loading ? (
        <div className="flex justify-center py-16"><Loader2 size={24} className="animate-spin text-muted-foreground" /></div>
      ) : categorias.length === 0 ? (
        <div className="glass rounded-2xl p-12 text-center">
          <Tags size={40} className="mx-auto text-muted-foreground/30 mb-3" />
          <p className="text-muted-foreground text-sm">No hay categorías creadas</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 stagger-children">
          {categorias.map((c) => (
            <div
              key={c.id}
              className="glass rounded-xl p-4 flex items-center justify-between group hover:bg-white/[0.03] transition-all duration-200"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-blue-500/10 flex items-center justify-center">
                  <Tags size={16} className="text-blue-400" />
                </div>
                <span className="text-sm font-medium">{c.nombre}</span>
              </div>
              <button
                onClick={() => handleDelete(c.id, c.nombre)}
                className="p-1.5 rounded-lg opacity-0 group-hover:opacity-100 hover:bg-red-500/10 text-muted-foreground hover:text-red-400 transition-all"
              >
                <Trash2 size={14} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
